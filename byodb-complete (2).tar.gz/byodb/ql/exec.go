package ql

import (
	"fmt"
	"slices"

	"byodb/btree"
	"byodb/kv"
	"byodb/relational"
)

// A query runs as a chain of iterators, each transforming the stream from the
// one below:
//
//	B+tree iterator   raw keys and values
//	  transaction     merged with this transaction's own writes
//	  Scanner         decoded rows, following secondary indexes
//	  scanIter        FILTER, OFFSET and LIMIT applied
//	  selectIter      output expressions evaluated
//
// Nothing materializes the result set. A query over more rows than fit in
// memory streams, and LIMIT stops the work rather than discarding it after the
// fact.

// RecordIter is a stream of rows.
type RecordIter interface {
	Valid() bool
	Next()
	Deref(*relational.Record) error
}

// Result is what running a statement produces: either a stream of rows, or a
// count of rows changed.
type Result struct {
	Rows     RecordIter // non-nil for SELECT
	Names    []string   // output column names, for SELECT
	Affected int64      // rows changed, for the other statements
}

// Execute runs one parsed statement inside a transaction.
func Execute(tx *relational.DBTX, stmt any) (*Result, error) {
	switch s := stmt.(type) {
	case *CreateTable:
		if err := tx.TableNew(s.Def); err != nil {
			return nil, err
		}
		return &Result{}, nil
	case *DropTable:
		if err := tx.TableDrop(s.Table); err != nil {
			return nil, err
		}
		return &Result{}, nil
	case *Select:
		return executeSelect(tx, s)
	case *Insert:
		return executeInsert(tx, s)
	case *Update:
		return executeUpdate(tx, s)
	case *Delete:
		return executeDelete(tx, s)
	default:
		return nil, fmt.Errorf("ql: cannot execute %T", stmt)
	}
}

// Run parses and executes a statement.
func Run(tx *relational.DBTX, query string) (*Result, error) {
	stmt, err := Parse(query)
	if err != nil {
		return nil, err
	}
	return Execute(tx, stmt)
}

// ---------- SELECT ----------

func executeSelect(tx *relational.DBTX, stmt *Select) (*Result, error) {
	rows, err := newScanIter(tx, &stmt.Scan)
	if err != nil {
		return nil, err
	}
	return &Result{
		Rows:  &selectIter{input: rows, names: stmt.Names, exprs: stmt.Output},
		Names: stmt.Names,
	}, nil
}

// selectIter evaluates the output expressions for each row.
type selectIter struct {
	input RecordIter
	names []string
	exprs []Node
}

func (it *selectIter) Valid() bool { return it.input.Valid() }
func (it *selectIter) Next()       { it.input.Next() }

func (it *selectIter) Deref(rec *relational.Record) error {
	var row relational.Record
	if err := it.input.Deref(&row); err != nil {
		return err
	}
	values := make([]relational.Value, len(it.exprs))
	for i, expr := range it.exprs {
		value, err := evalExpr(row, expr)
		if err != nil {
			return err
		}
		values[i] = value
	}
	rec.Cols, rec.Vals = it.names, values
	return nil
}

// ---------- the scan, filter and limit stage ----------

// scanIter applies FILTER, OFFSET and LIMIT to the rows a Scanner produces.
//
// It runs one row ahead: the next result is found and cached during Next, so
// Valid can answer without the caller having to distinguish "no more rows in
// the range" from "no more rows that pass the filter".
type scanIter struct {
	scanner relational.Scanner
	filter  Node
	offset  int64
	limit   int64

	matched int64 // rows that passed the filter, including skipped ones
	current relational.Record
	valid   bool
	err     error
}

func newScanIter(tx *relational.DBTX, scan *Scan) (*scanIter, error) {
	it := &scanIter{filter: scan.Filter, offset: scan.Offset, limit: scan.Limit}
	if err := setUpScan(tx, scan, &it.scanner); err != nil {
		return nil, err
	}
	it.advance()
	return it, it.err
}

func (it *scanIter) Valid() bool { return it.valid && it.err == nil }

func (it *scanIter) Next() {
	if it.valid {
		it.advance()
	}
}

func (it *scanIter) Deref(rec *relational.Record) error {
	if it.err != nil {
		return it.err
	}
	if !it.valid {
		return fmt.Errorf("ql: Deref called on a finished result")
	}
	*rec = it.current
	return nil
}

// Err reports a failure that ended the scan early, which Valid alone cannot
// distinguish from a scan that simply finished.
func (it *scanIter) Err() error { return it.err }

func (it *scanIter) advance() {
	for it.scanner.Valid() {
		var row relational.Record
		if err := it.scanner.Deref(&row); err != nil {
			it.err, it.valid = err, false
			return
		}
		it.scanner.Next()

		if it.filter.isSet() {
			verdict, err := evalExpr(row, it.filter)
			if err != nil {
				it.err, it.valid = err, false
				return
			}
			if !truthy(verdict) {
				continue
			}
		}

		it.matched++
		if it.matched <= it.offset {
			continue // inside OFFSET
		}
		if it.matched-it.offset > it.limit {
			it.valid = false // past LIMIT; stop scanning
			return
		}
		it.current, it.valid = row, true
		return
	}
	it.valid = false
}

// setUpScan turns the INDEX BY clause into a range over a chosen index.
func setUpScan(tx *relational.DBTX, scan *Scan, out *relational.Scanner) error {
	var err error
	if out.Key1, out.Cmp1, err = scanBound(scan.Key1); err != nil {
		return err
	}
	if out.Key2, out.Cmp2, err = scanBound(scan.Key2); err != nil {
		return err
	}

	// A clause that names only one end has to be completed, and what completes
	// it depends on the operator. See the infinity encoding in the relational
	// layer: an unconstrained end is the empty tuple, which every index covers.
	switch {
	case !scan.Key1.isSet() && !scan.Key2.isSet():
		// No INDEX BY: walk the whole table in primary key order.
		out.Cmp1, out.Cmp2 = btree.CmpGE, btree.CmpLE

	case scan.Key1.Type == NodeEq && !scan.Key2.isSet():
		// `index by a = 1` is the prefix of the index where a is 1, which is
		// the closed interval from (1, -inf) to (1, +inf).
		out.Key2 = out.Key1
		out.Cmp1, out.Cmp2 = btree.CmpGE, btree.CmpLE

	case scan.Key1.isSet() && !scan.Key2.isSet():
		// `index by a > 1` runs to the end of the index in that direction.
		if out.Cmp1 > 0 {
			out.Cmp2 = btree.CmpLE
		} else {
			out.Cmp2 = btree.CmpGE
		}

	case scan.Key1.Type == NodeEq || scan.Key2.Type == NodeEq:
		return evalErrorf("`=` in INDEX BY already covers a whole range and cannot be " +
			"combined with another bound")
	}

	return tx.Scan(scan.Table, out)
}

// scanBound converts one comparison from INDEX BY into a record of column
// values and a comparison operator.
func scanBound(node Node) (relational.Record, int, error) {
	if !node.isSet() {
		return relational.Record{}, 0, nil
	}
	if !node.isComparison() {
		return relational.Record{}, 0, evalErrorf("INDEX BY needs a comparison, found %s",
			nodeName(node.Type))
	}

	cmp, ok := map[int]int{
		NodeEq: btree.CmpGE, // refined by the caller into a closed interval
		NodeGE: btree.CmpGE,
		NodeGT: btree.CmpGT,
		NodeLE: btree.CmpLE,
		NodeLT: btree.CmpLT,
	}[node.Type]
	if !ok {
		return relational.Record{}, 0, evalErrorf("INDEX BY cannot use %s", nodeName(node.Type))
	}

	columns := tupleItems(node.Kids[0])
	values := tupleItems(node.Kids[1])
	if len(columns) != len(values) {
		return relational.Record{}, 0, evalErrorf(
			"INDEX BY compares %d columns with %d values", len(columns), len(values))
	}

	var rec relational.Record
	for i, col := range columns {
		if col.Type != NodeSym {
			return relational.Record{}, 0, evalErrorf(
				"the left side of an INDEX BY comparison must be a column name, found %s",
				nodeName(col.Type))
		}
		// The bound must be a constant: it is evaluated once, before any row
		// exists, to locate where the scan starts.
		value, err := evalExpr(relational.Record{}, values[i])
		if err != nil {
			return relational.Record{}, 0, evalErrorf(
				"the INDEX BY bound for %s must be a constant: %s", col.Str, err)
		}
		rec.Add(string(col.Str), value)
	}
	return rec, cmp, nil
}

// tupleItems flattens a tuple node into its items, treating a single
// expression as a one-item tuple.
func tupleItems(node Node) []Node {
	if node.Type == NodeTuple {
		return node.Kids
	}
	return []Node{node}
}

// ---------- INSERT ----------

func executeInsert(tx *relational.DBTX, stmt *Insert) (*Result, error) {
	tdef, err := tx.TableDef(stmt.Table)
	if err != nil {
		return nil, err
	}
	for _, col := range stmt.Cols {
		if !slices.Contains(tdef.Cols, col) {
			return nil, fmt.Errorf("%w: table %s has no column %s",
				relational.ErrBadRecord, stmt.Table, col)
		}
	}

	var affected int64
	for rowNumber, row := range stmt.Values {
		var rec relational.Record
		for i, expr := range row {
			// An empty environment: the values must be constants, since there
			// is no row yet for a column reference to mean anything.
			value, err := evalExpr(relational.Record{}, expr)
			if err != nil {
				return nil, fmt.Errorf("row %d, column %s: %w", rowNumber+1, stmt.Cols[i], err)
			}
			rec.Add(stmt.Cols[i], value)
		}
		added, err := tx.Set(stmt.Table, rec, stmt.Mode)
		if err != nil {
			return nil, err
		}
		if !added && stmt.Mode == kv.ModeInsertOnly {
			return nil, fmt.Errorf("row %d: a row with this primary key already exists "+
				"(use REPLACE INTO to overwrite)", rowNumber+1)
		}
		if added {
			affected++
		}
	}
	return &Result{Affected: affected}, nil
}

// ---------- UPDATE and DELETE ----------

// collectRows reads a scan to completion before anything is modified.
//
// Modifying rows while iterating over them would change the range being
// walked underneath the iterator; reading first keeps the two apart.
func collectRows(tx *relational.DBTX, scan *Scan) ([]relational.Record, error) {
	iter, err := newScanIter(tx, scan)
	if err != nil {
		return nil, err
	}
	var rows []relational.Record
	for ; iter.Valid(); iter.Next() {
		var rec relational.Record
		if err := iter.Deref(&rec); err != nil {
			return nil, err
		}
		// Copied defensively. Decoding a row already allocates its strings,
		// so today this is redundant — but the rows outlive the writes below,
		// which move pages around, and relying on the decoder's allocation
		// behavior from up here would be a trap for anyone optimizing it.
		// relational.TestDerefReturnsIndependentMemory pins that behavior.
		rows = append(rows, copyRecord(rec))
	}
	return rows, iter.Err()
}

func copyRecord(rec relational.Record) relational.Record {
	out := relational.Record{
		Cols: append([]string(nil), rec.Cols...),
		Vals: append([]relational.Value(nil), rec.Vals...),
	}
	for i := range out.Vals {
		if out.Vals[i].Type == relational.TypeBytes {
			out.Vals[i].Str = append([]byte(nil), out.Vals[i].Str...)
		}
	}
	return out
}

func executeUpdate(tx *relational.DBTX, stmt *Update) (*Result, error) {
	tdef, err := tx.TableDef(stmt.Table)
	if err != nil {
		return nil, err
	}
	primaryKey := tdef.Indexes[0]
	for _, col := range stmt.Names {
		if !slices.Contains(tdef.Cols, col) {
			return nil, fmt.Errorf("%w: table %s has no column %s",
				relational.ErrBadRecord, stmt.Table, col)
		}
		if slices.Contains(primaryKey, col) {
			// Changing a primary key column moves the row to a different key,
			// which is a delete plus an insert rather than an update. Refusing
			// is clearer than quietly doing one of the two.
			return nil, fmt.Errorf("%w: %s is part of the primary key of %s and cannot "+
				"be updated; delete the row and insert it again",
				relational.ErrBadRecord, col, stmt.Table)
		}
	}

	rows, err := collectRows(tx, &stmt.Scan)
	if err != nil {
		return nil, err
	}

	var affected int64
	for _, row := range rows {
		updated := copyRecord(row)
		for i, col := range stmt.Names {
			// Expressions see the row as it was before this statement, so
			// `set a = a + 1` means the old a, and two assignments in one
			// statement cannot depend on each other's results.
			value, err := evalExpr(row, stmt.Values[i])
			if err != nil {
				return nil, err
			}
			want := tdef.Types[slices.Index(tdef.Cols, col)]
			if value.Type != want {
				return nil, fmt.Errorf("%w: column %s is %s, but the new value is %s",
					relational.ErrBadRecord, col, relational.TypeName(want),
					relational.TypeName(value.Type))
			}
			*updated.Get(col) = value
		}
		changed, err := tx.Update(stmt.Table, updated)
		if err != nil {
			return nil, err
		}
		if changed {
			affected++
		}
	}
	return &Result{Affected: affected}, nil
}

func executeDelete(tx *relational.DBTX, stmt *Delete) (*Result, error) {
	tdef, err := tx.TableDef(stmt.Table)
	if err != nil {
		return nil, err
	}
	rows, err := collectRows(tx, &stmt.Scan)
	if err != nil {
		return nil, err
	}

	var affected int64
	for _, row := range rows {
		// Only the primary key is needed to identify the row.
		var key relational.Record
		for _, col := range tdef.Indexes[0] {
			key.Add(col, *row.Get(col))
		}
		deleted, err := tx.Delete(stmt.Table, key)
		if err != nil {
			return nil, err
		}
		if deleted {
			affected++
		}
	}
	return &Result{Affected: affected}, nil
}
