// Package ql is the query language: a parser and an interpreter for a
// SQL-like syntax over the relational layer.
//
// The language deliberately splits what SQL puts in one WHERE clause into two:
//
//	INDEX BY   chooses the index and the range to scan
//	FILTER     tests each row the scan produces
//
// A real database infers that split with a query planner. Making it explicit
// costs a little syntax and buys predictable performance — the query does what
// it says, and cannot silently change plan as the data grows.
package ql

import (
	"fmt"
	"math"

	"byodb/relational"
)

// Node types. An expression is a tree of these.
const (
	NodeUnset = iota

	// Leaves.
	NodeSym // a column name
	NodeInt // an integer literal
	NodeStr // a string literal

	// Boolean operators, lowest precedence first.
	NodeOr
	NodeAnd
	NodeNot

	// Comparisons.
	NodeEq
	NodeNE
	NodeLT
	NodeLE
	NodeGT
	NodeGE

	// Arithmetic.
	NodeAdd
	NodeSub
	NodeMul
	NodeDiv
	NodeMod
	NodeNeg

	// A parenthesized list, used for multi-column index bounds.
	NodeTuple
)

var nodeNames = map[int]string{
	NodeSym: "column", NodeInt: "integer", NodeStr: "string",
	NodeOr: "OR", NodeAnd: "AND", NodeNot: "NOT",
	NodeEq: "=", NodeNE: "!=", NodeLT: "<", NodeLE: "<=", NodeGT: ">", NodeGE: ">=",
	NodeAdd: "+", NodeSub: "-", NodeMul: "*", NodeDiv: "/", NodeMod: "%", NodeNeg: "-",
	NodeTuple: "tuple",
}

func nodeName(t int) string {
	if name, ok := nodeNames[t]; ok {
		return name
	}
	return fmt.Sprintf("node(%d)", t)
}

// Node is one expression node: a tagged union with operands.
type Node struct {
	Type int
	I64  int64
	Str  []byte
	Kids []Node
}

func (n Node) isSet() bool { return n.Type != NodeUnset }

// isComparison reports whether the node is one of the six comparison
// operators, which are the only forms INDEX BY accepts.
func (n Node) isComparison() bool {
	switch n.Type {
	case NodeEq, NodeNE, NodeLT, NodeLE, NodeGT, NodeGE:
		return true
	}
	return false
}

// Scan is what SELECT, UPDATE and DELETE have in common: which rows to act on.
type Scan struct {
	Table  string
	Key1   Node // the INDEX BY lower or starting bound
	Key2   Node // the INDEX BY upper or ending bound
	Filter Node // an arbitrary predicate applied to each row
	Offset int64
	Limit  int64
}

func newScan() Scan { return Scan{Offset: 0, Limit: math.MaxInt64} }

// Statements.
type (
	// Select projects expressions over the rows a scan produces.
	Select struct {
		Scan
		Names  []string // output column names, from AS or derived
		Output []Node
	}

	// Update assigns expressions to columns of the rows a scan produces.
	Update struct {
		Scan
		Names  []string
		Values []Node
	}

	// Delete removes the rows a scan produces.
	Delete struct {
		Scan
	}

	// Insert adds literal rows. Mode distinguishes INSERT from REPLACE.
	Insert struct {
		Table  string
		Mode   int // relational insert mode
		Cols   []string
		Values [][]Node
	}

	// CreateTable defines a new table.
	CreateTable struct {
		Def *relational.TableDef
	}

	// DropTable removes a table and everything in it.
	DropTable struct {
		Table string
	}
)
