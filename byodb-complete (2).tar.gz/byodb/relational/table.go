package relational

import (
	"fmt"

	"byodb/kv"
)

// A row is stored as one key-value pair per index.
//
//	primary key   | prefix | pk columns...            | -> | other columns... |
//	secondary idx | prefix | indexed cols... | pk cols | -> | (empty)          |
//
// A secondary index appends the primary key to its own columns for two
// reasons: it makes otherwise-duplicate index entries unique, so the tree needs
// no support for duplicate keys, and it gives the scan a way back to the full
// row.

// Get looks up a single row by its primary key. rec supplies the key columns
// and receives the whole row.
func (tx *DBTX) Get(table string, rec *Record) (bool, error) {
	tdef, err := tx.TableDef(table)
	if err != nil {
		return false, err
	}
	return tx.get(tdef, rec)
}

func (tx *DBTX) get(tdef *TableDef, rec *Record) (bool, error) {
	values, err := checkRecord(tdef, *rec, tdef.PKeyCount())
	if err != nil {
		return false, err
	}
	key := encodeKey(nil, tdef.Prefixes[0], values[:tdef.PKeyCount()])
	encoded, ok := tx.kv.Get(key)
	if !ok {
		return false, nil
	}
	if err := decodeRow(tdef, values, encoded); err != nil {
		return false, err
	}
	rec.Cols = tdef.Cols
	rec.Vals = values
	return true, nil
}

// decodeRow fills in the non-key columns from a stored value.
func decodeRow(tdef *TableDef, values []Value, encoded []byte) error {
	n := tdef.PKeyCount()
	for i := n; i < len(tdef.Cols); i++ {
		values[i] = Value{Type: tdef.Types[i]}
	}
	return decodeValues(encoded, values[n:])
}

// Insert adds a row, failing if the primary key already exists.
func (tx *DBTX) Insert(table string, rec Record) (bool, error) {
	return tx.Set(table, rec, kv.ModeInsertOnly)
}

// Update modifies an existing row, failing if the primary key is absent.
func (tx *DBTX) Update(table string, rec Record) (bool, error) {
	return tx.Set(table, rec, kv.ModeUpdateOnly)
}

// Upsert adds a row or replaces an existing one.
func (tx *DBTX) Upsert(table string, rec Record) (bool, error) {
	return tx.Set(table, rec, kv.ModeUpsert)
}

// Set writes a whole row according to mode.
func (tx *DBTX) Set(table string, rec Record, mode int) (bool, error) {
	tdef, err := tx.TableDef(table)
	if err != nil {
		return false, err
	}
	return tx.set(tdef, rec, mode)
}

// set writes the row and brings every index into line with it.
//
// The order matters: the primary row is written first because its result says
// what happened — whether the row is new, and if not, what it used to contain.
// Only that tells us which stale index entries to remove.
func (tx *DBTX) set(tdef *TableDef, rec Record, mode int) (bool, error) {
	values, err := checkRecord(tdef, rec, len(tdef.Cols))
	if err != nil {
		return false, err
	}
	n := tdef.PKeyCount()

	req := kv.UpdateReq{
		Key:  encodeKey(nil, tdef.Prefixes[0], values[:n]),
		Val:  encodeValues(nil, values[n:]),
		Mode: mode,
	}
	if err := tx.kv.Update(&req); err != nil {
		return false, err
	}
	if !req.Updated {
		return false, nil // the mode rejected this row; nothing changed
	}
	if len(tdef.Indexes) == 1 {
		return true, nil
	}

	// A replaced row's old column values may have been indexed under different
	// keys, which would otherwise be left behind pointing at data that no
	// longer matches.
	if !req.Added {
		previous := make([]Value, len(values))
		copy(previous, values[:n]) // the primary key is unchanged by definition
		if err := decodeRow(tdef, previous, req.Old); err != nil {
			return false, err
		}
		if err := tx.updateIndexes(tdef, previous, false); err != nil {
			return false, err
		}
	}
	if err := tx.updateIndexes(tdef, values, true); err != nil {
		return false, err
	}
	return true, nil
}

// Delete removes a row by its primary key.
func (tx *DBTX) Delete(table string, rec Record) (bool, error) {
	tdef, err := tx.TableDef(table)
	if err != nil {
		return false, err
	}
	return tx.deleteRow(tdef, rec)
}

func (tx *DBTX) deleteRow(tdef *TableDef, rec Record) (bool, error) {
	values, err := checkRecord(tdef, rec, tdef.PKeyCount())
	if err != nil {
		return false, err
	}
	n := tdef.PKeyCount()

	req := kv.DeleteReq{Key: encodeKey(nil, tdef.Prefixes[0], values[:n])}
	deleted, err := tx.kv.Del(&req)
	if err != nil || !deleted {
		return false, err
	}
	if len(tdef.Indexes) == 1 {
		return true, nil
	}

	// The row that was deleted is the one whose index entries must go, so the
	// removed value is decoded to recover the columns those entries were
	// built from.
	if err := decodeRow(tdef, values, req.Old); err != nil {
		return false, err
	}
	if err := tx.updateIndexes(tdef, values, false); err != nil {
		return false, err
	}
	return true, nil
}

// updateIndexes adds or removes the secondary index entries for one row.
func (tx *DBTX) updateIndexes(tdef *TableDef, values []Value, add bool) error {
	for i := 1; i < len(tdef.Indexes); i++ {
		key := encodeIndexKey(tdef, i, values)
		if add {
			req := kv.UpdateReq{Key: key, Val: nil, Mode: kv.ModeUpsert}
			if err := tx.kv.Update(&req); err != nil {
				return err
			}
		} else if _, err := tx.kv.Del(&kv.DeleteReq{Key: key}); err != nil {
			return err
		}
	}
	return nil
}

// encodeIndexKey builds one secondary index entry: the indexed columns
// followed by the primary key columns.
func encodeIndexKey(tdef *TableDef, index int, values []Value) []byte {
	cols := make([]Value, 0, len(tdef.Indexes[index])+tdef.PKeyCount())
	for _, name := range tdef.Indexes[index] {
		cols = append(cols, values[columnIndex(tdef, name)])
	}
	// Appending the primary key makes the entry unique and gives a scan its
	// route back to the row.
	for _, name := range tdef.Indexes[0] {
		cols = append(cols, values[columnIndex(tdef, name)])
	}
	return encodeKey(nil, tdef.Prefixes[index], cols)
}

func columnIndex(tdef *TableDef, name string) int {
	for i, col := range tdef.Cols {
		if col == name {
			return i
		}
	}
	panic(fmt.Sprintf("relational: table %q has no column %q", tdef.Name, name))
}
