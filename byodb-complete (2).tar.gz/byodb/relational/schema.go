package relational

import (
	"encoding/json"
	"fmt"
	"slices"

	"byodb/btree"
	"byodb/kv"
)

// TableDef is a table's schema.
//
// Indexes[0] is the primary key. Treating the primary key as simply the first
// index removes a whole category of special cases: index selection, encoding
// and maintenance all work the same way whichever index is chosen, and the
// only thing that distinguishes the primary one is that it is unique and its
// entries carry the row's remaining columns as their value.
type TableDef struct {
	Name     string
	Cols     []string
	Types    []uint32
	Indexes  [][]string // Indexes[0] is the primary key
	Prefixes []uint32   // one B+tree key prefix per index
}

// PKeyCount is the number of columns in the primary key. Because TableNew
// reorders columns so the primary key comes first, these are always Cols[:n].
func (tdef *TableDef) PKeyCount() int { return len(tdef.Indexes[0]) }

// Reserved key prefixes. Prefix 0 is left unused so that a zero value is never
// mistaken for a real table.
const (
	prefixMeta      = 1 // the @meta table
	prefixTable     = 2 // the @table table
	firstUserPrefix = 3
)

// Internal tables. The database stores its own schemas the same way it stores
// user data — the only bootstrap needed is that these two definitions live in
// code rather than on disk, so there is something to read the others with.
var (
	tableMeta = &TableDef{
		Name:     "@meta",
		Cols:     []string{"key", "val"},
		Types:    []uint32{TypeBytes, TypeBytes},
		Indexes:  [][]string{{"key"}},
		Prefixes: []uint32{prefixMeta},
	}
	tableSchemas = &TableDef{
		Name:     "@table",
		Cols:     []string{"name", "def"},
		Types:    []uint32{TypeBytes, TypeBytes},
		Indexes:  [][]string{{"name"}},
		Prefixes: []uint32{prefixTable},
	}
)

// metaNextPrefix is the @meta key holding the counter that hands out key
// prefixes to new tables and indexes.
const metaNextPrefix = "next_prefix"

// normalize validates a user-supplied definition and puts it in the canonical
// shape: primary key columns first, in primary key order.
//
// Reordering here means the rest of the code can assume the primary key is
// Cols[:n], so encoding a row splits at a single index instead of gathering
// scattered columns.
func normalize(tdef *TableDef) error {
	switch {
	case tdef.Name == "":
		return fmt.Errorf("%w: the table has no name", ErrBadSchema)
	case len(tdef.Cols) == 0:
		return fmt.Errorf("%w: table %q has no columns", ErrBadSchema, tdef.Name)
	case len(tdef.Cols) != len(tdef.Types):
		return fmt.Errorf("%w: table %q has %d columns but %d types",
			ErrBadSchema, tdef.Name, len(tdef.Cols), len(tdef.Types))
	case len(tdef.Indexes) == 0 || len(tdef.Indexes[0]) == 0:
		return fmt.Errorf("%w: table %q has no primary key", ErrBadSchema, tdef.Name)
	}

	seen := map[string]bool{}
	for i, col := range tdef.Cols {
		if col == "" {
			return fmt.Errorf("%w: table %q has an unnamed column", ErrBadSchema, tdef.Name)
		}
		if seen[col] {
			return fmt.Errorf("%w: table %q declares column %q twice", ErrBadSchema, tdef.Name, col)
		}
		seen[col] = true
		if tdef.Types[i] != TypeBytes && tdef.Types[i] != TypeInt64 {
			return fmt.Errorf("%w: column %q has unrecognized type %d",
				ErrBadSchema, col, tdef.Types[i])
		}
	}

	for _, index := range tdef.Indexes {
		if len(index) == 0 {
			return fmt.Errorf("%w: table %q has an empty index", ErrBadSchema, tdef.Name)
		}
		inIndex := map[string]bool{}
		for _, col := range index {
			if !seen[col] {
				return fmt.Errorf("%w: index on table %q names unknown column %q",
					ErrBadSchema, tdef.Name, col)
			}
			if inIndex[col] {
				return fmt.Errorf("%w: index on table %q uses column %q twice",
					ErrBadSchema, tdef.Name, col)
			}
			inIndex[col] = true
		}
	}

	// Move the primary key columns to the front, keeping the declared order of
	// everything else.
	pkey := tdef.Indexes[0]
	cols := append([]string(nil), pkey...)
	types := make([]uint32, 0, len(tdef.Cols))
	for _, col := range pkey {
		types = append(types, tdef.Types[slices.Index(tdef.Cols, col)])
	}
	for i, col := range tdef.Cols {
		if !slices.Contains(pkey, col) {
			cols = append(cols, col)
			types = append(types, tdef.Types[i])
		}
	}
	tdef.Cols, tdef.Types = cols, types
	return nil
}

// TableNew creates a table.
//
// Four keys change: the schema row, and the prefix counter — plus one prefix
// allocation per index. They all land in this transaction, so a half-created
// table is not a state the database can be left in.
func (tx *DBTX) TableNew(tdef *TableDef) error {
	if err := normalize(tdef); err != nil {
		return err
	}
	if existing, err := tx.getTableDef(tdef.Name); err != nil {
		return err
	} else if existing != nil {
		return fmt.Errorf("%w: %s", ErrTableExists, tdef.Name)
	}

	// Allocate one key prefix per index from the shared counter.
	next, err := tx.nextPrefix()
	if err != nil {
		return err
	}
	tdef.Prefixes = nil
	for range tdef.Indexes {
		tdef.Prefixes = append(tdef.Prefixes, next)
		next++
	}
	if err := tx.setNextPrefix(next); err != nil {
		return err
	}

	encoded, err := json.Marshal(tdef)
	if err != nil {
		return fmt.Errorf("relational: encoding the schema of %q: %w", tdef.Name, err)
	}
	row := (&Record{}).AddStr("name", []byte(tdef.Name)).AddStr("def", encoded)
	added, err := tx.set(tableSchemas, *row, kv.ModeInsertOnly)
	if err != nil {
		return err
	}
	if !added {
		return fmt.Errorf("%w: %s", ErrTableExists, tdef.Name)
	}
	// The cache recorded the absence of this table a moment ago; the rest of
	// this transaction must see it now.
	tx.schemas[tdef.Name] = tdef
	return nil
}

// TableDrop removes a table's schema and every row and index entry it owns.
func (tx *DBTX) TableDrop(name string) error {
	tdef, err := tx.getTableDef(name)
	if err != nil {
		return err
	}
	if tdef == nil {
		return fmt.Errorf("%w: %s", ErrTableNotFound, name)
	}

	// Collect the primary keys first: deleting rows while scanning them would
	// mutate the range being walked.
	var rows []Record
	scanner := Scanner{Cmp1: btree.CmpGE, Cmp2: btree.CmpLE}
	if err := tx.scanAll(tdef, &scanner); err != nil {
		return err
	}
	for ; scanner.Valid(); scanner.Next() {
		var rec Record
		if err := scanner.Deref(&rec); err != nil {
			return err
		}
		rows = append(rows, rec)
	}
	for _, rec := range rows {
		if _, err := tx.deleteRow(tdef, rec); err != nil {
			return err
		}
	}

	key := (&Record{}).AddStr("name", []byte(name))
	if _, err := tx.deleteRow(tableSchemas, *key); err != nil {
		return err
	}
	tx.schemas[name] = nil
	return nil
}

// TableList returns the names of the user tables, in order.
func (tx *DBTX) TableList() ([]string, error) {
	var names []string
	scanner := Scanner{Cmp1: btree.CmpGE, Cmp2: btree.CmpLE}
	if err := tx.scanAll(tableSchemas, &scanner); err != nil {
		return nil, err
	}
	for ; scanner.Valid(); scanner.Next() {
		var rec Record
		if err := scanner.Deref(&rec); err != nil {
			return nil, err
		}
		names = append(names, string(rec.Get("name").Str))
	}
	return names, nil
}

// TableDef returns a table's schema, or ErrTableNotFound.
func (tx *DBTX) TableDef(name string) (*TableDef, error) {
	tdef, err := tx.getTableDef(name)
	if err != nil {
		return nil, err
	}
	if tdef == nil {
		return nil, fmt.Errorf("%w: %s", ErrTableNotFound, name)
	}
	return tdef, nil
}

// getTableDef reads a schema, returning nil when the table does not exist.
func (tx *DBTX) getTableDef(name string) (*TableDef, error) {
	switch name {
	case tableMeta.Name:
		return tableMeta, nil
	case tableSchemas.Name:
		return tableSchemas, nil
	}
	if cached, ok := tx.schemas[name]; ok {
		return cached, nil // nil is cached too: "this table does not exist"
	}

	rec := (&Record{}).AddStr("name", []byte(name))
	found, err := tx.get(tableSchemas, rec)
	if err != nil {
		return nil, err
	}
	if !found {
		tx.schemas[name] = nil
		return nil, nil
	}
	tdef := &TableDef{}
	if err := json.Unmarshal(rec.Get("def").Str, tdef); err != nil {
		return nil, fmt.Errorf("relational: schema of %q is corrupt: %w", name, err)
	}
	tx.schemas[name] = tdef
	return tdef, nil
}

func (tx *DBTX) nextPrefix() (uint32, error) {
	rec := (&Record{}).AddStr("key", []byte(metaNextPrefix))
	found, err := tx.get(tableMeta, rec)
	if err != nil {
		return 0, err
	}
	if !found {
		return firstUserPrefix, nil
	}
	var value uint32
	if _, err := fmt.Sscanf(string(rec.Get("val").Str), "%d", &value); err != nil {
		return 0, fmt.Errorf("relational: the table prefix counter is corrupt: %w", err)
	}
	if value < firstUserPrefix {
		return firstUserPrefix, nil
	}
	return value, nil
}

func (tx *DBTX) setNextPrefix(value uint32) error {
	rec := (&Record{}).
		AddStr("key", []byte(metaNextPrefix)).
		AddStr("val", []byte(fmt.Sprintf("%d", value)))
	_, err := tx.set(tableMeta, *rec, kv.ModeUpsert)
	return err
}
